SELECT Employees.FirstName, Employees.LastName, Employees.Salary
FROM Employees