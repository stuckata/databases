SELECT DISTINCT Employees.Salary AS 'Different employees salaries'
FROM Employees