SELECT d.Name
FROM Departments d
UNION
SELECT t.Name
FROM Towns t