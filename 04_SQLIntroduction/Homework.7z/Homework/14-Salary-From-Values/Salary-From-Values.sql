SELECT *
FROM Employees
WHERE Employees.Salary IN (25000, 14000, 12500, 23600)