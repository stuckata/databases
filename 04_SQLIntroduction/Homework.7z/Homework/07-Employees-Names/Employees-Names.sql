SELECT Employees.FirstName + ' ' + Employees.LastName AS Name
FROM Employees
