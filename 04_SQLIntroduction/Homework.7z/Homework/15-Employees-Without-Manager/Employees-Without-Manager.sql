SELECT *
FROM Employees
WHERE Employees.ManagerID IS NULL