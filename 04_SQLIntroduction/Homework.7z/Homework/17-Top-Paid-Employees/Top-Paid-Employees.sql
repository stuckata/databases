SELECT TOP 5 *
FROM Employees
ORDER BY Employees.Salary DESC
