SELECT *
FROM Employees
WHERE Employees.FirstName LIKE 'SA%'