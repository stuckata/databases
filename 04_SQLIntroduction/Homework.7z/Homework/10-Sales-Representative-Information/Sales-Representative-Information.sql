SELECT * 
FROM Employees
WHERE Employees.JobTitle = 'Sales Representative'