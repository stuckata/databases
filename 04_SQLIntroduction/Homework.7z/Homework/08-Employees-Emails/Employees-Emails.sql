SELECT Employees.FirstName + '.' + Employees.LastName + '@softuni.bg' AS 'Full Email Adresses'
FROM Employees