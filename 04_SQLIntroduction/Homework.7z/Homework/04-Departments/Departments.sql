SELECT * 
FROM Departments