SELECT Departments.Name
FROM Departments