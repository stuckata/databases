SELECT *
FROM Employees
WHERE Employees.LastName LIKE '%ei%'